#!/usr/bin/env bash
#
# Install the ARRIVE CLI from an extracted Linux tarball (or from inside the tarball
# directory before extraction). Mirrors the macOS .pkg / Windows MSI post-install:
#   - arrive  -> ~/.local/bin/arrive (or --dir)
#   - templates -> ~/.arrive/templates
#
# Usage:
#   ./install-from-tarball.sh
#   ./install-from-tarball.sh --dir ~/.cargo/bin
#   ./install-from-tarball.sh --prefix /opt/arrive
#
set -euo pipefail

INSTALL_DIR=""
PREFIX=""

usage() {
  cat <<'EOF'
Usage:
  install-from-tarball.sh [--dir DIR]
  install-from-tarball.sh --prefix DIR

  --dir DIR      Install only the arrive binary to DIR (default: ~/.local/bin)
  --prefix DIR   Install arrive to DIR/bin and templates to DIR/share/arrive/templates
                 (also seeds ~/.arrive/templates for the CLI lookup path)
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dir)
      INSTALL_DIR="${2:?--dir requires a path}"
      shift 2
      ;;
    --prefix)
      PREFIX="${2:?--prefix requires a path}"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -n "$PREFIX" ]]; then
  INSTALL_DIR="$PREFIX/bin"
  TEMPLATES_SRC="$SCRIPT_DIR/share/arrive/templates"
  TEMPLATES_PKG="$PREFIX/share/arrive/templates"
else
  if [[ -z "$INSTALL_DIR" ]]; then
    if [[ -d "$HOME/.local/bin" ]] || [[ -w "$HOME/.local" ]]; then
      INSTALL_DIR="$HOME/.local/bin"
    elif [[ -d "$HOME/.cargo/bin" ]]; then
      INSTALL_DIR="$HOME/.cargo/bin"
    else
      INSTALL_DIR="$HOME/.local/bin"
    fi
  fi
  TEMPLATES_SRC="$SCRIPT_DIR/share/arrive/templates"
  TEMPLATES_PKG=""
fi

ARRIVE_BIN="$SCRIPT_DIR/arrive"
if [[ ! -x "$ARRIVE_BIN" ]]; then
  echo "Error: expected executable at $ARRIVE_BIN" >&2
  echo "Run this script from the root of an extracted arrive-cli-*-linux-*.tar.gz" >&2
  exit 1
fi

if [[ ! -d "$TEMPLATES_SRC" ]]; then
  echo "Error: templates not found at $TEMPLATES_SRC" >&2
  exit 1
fi

mkdir -p "$INSTALL_DIR"
cp "$ARRIVE_BIN" "$INSTALL_DIR/arrive"
chmod +x "$INSTALL_DIR/arrive"
echo "Installed arrive -> $INSTALL_DIR/arrive"

USER_TEMPLATES="${ARRIVE_CONFIG_DIR:-$HOME/.arrive}/templates"
mkdir -p "$(dirname "$USER_TEMPLATES")"
rm -rf "$USER_TEMPLATES"
mkdir -p "$USER_TEMPLATES"
cp -a "$TEMPLATES_SRC/." "$USER_TEMPLATES/"
echo "Installed templates -> $USER_TEMPLATES"

if [[ -n "$TEMPLATES_PKG" ]]; then
  mkdir -p "$(dirname "$TEMPLATES_PKG")"
  rm -rf "$TEMPLATES_PKG"
  mkdir -p "$TEMPLATES_PKG"
  cp -a "$TEMPLATES_SRC/." "$TEMPLATES_PKG/"
  echo "Installed templates (prefix) -> $TEMPLATES_PKG"
fi

if [[ -f "$SCRIPT_DIR/VERSION" ]]; then
  echo "Package version: $(tr -d '\n' < "$SCRIPT_DIR/VERSION")"
fi

if [[ ":$PATH:" != *":$INSTALL_DIR:"* ]]; then
  echo
  echo "Note: $INSTALL_DIR is not on PATH. Add:"
  echo "  export PATH=\"$INSTALL_DIR:\$PATH\""
fi

echo
"$INSTALL_DIR/arrive" --version
echo
echo "Try: arrive --help && arrive init --yes"
