ARRIVE CLI — Linux x86_64 (glibc)

Install (user-local, no root):
  mkdir -p /tmp/arrive-cli && tar -xzf arrive-cli-v0.1.7-linux-x86_64.tar.gz -C /tmp/arrive-cli
  /tmp/arrive-cli/install-from-tarball.sh

Verify:
  arrive --version
  arrive --help

Runtime: requires glibc + libdbus (Secret Service). Headless VMs without a
keyring daemon use the documented ~/.arrive token file fallback (0600).
