"""ARRIVE LiteLLM attribution callback (sample).

Install this as a LiteLLM custom callback so every routed request is attributed to
the active ARRIVE advance and appended to a local ledger that
`arrive usage import --from litellm` reads.

It reads the active advance from `<repo>/.arrive/work-context.json` and appends a
normalized event to `<repo>/.arrive/usage/litellm-events.jsonl` (git-ignored).

Set `ARRIVE_REPO_ROOT` to the repo path, or rely on the process CWD.

NOTE: the LiteLLM callback signature and the usage field names depend on your
LiteLLM version and the upstream provider; adjust `g(...)` keys as needed.
"""

import datetime
import json
import os
from pathlib import Path


def _repo_root() -> Path:
    return Path(os.environ.get("ARRIVE_REPO_ROOT", os.getcwd()))


def _active_advance(repo: Path):
    wc = repo / ".arrive" / "work-context.json"
    try:
        data = json.loads(wc.read_text())
    except Exception:
        return None
    slots = data.get("slots", {})
    for key in ["default", *slots.keys()]:
        slot = slots.get(key)
        if slot and slot.get("advance_id"):
            return slot["advance_id"]
    return None


def log_arrive_usage(kwargs, response_obj, start_time, end_time):
    repo = _repo_root()
    advance_id = _active_advance(repo)
    if not advance_id:
        return  # nothing to attribute

    usage = getattr(response_obj, "usage", None) or {}

    def g(k):
        if isinstance(usage, dict):
            return int(usage.get(k, 0) or 0)
        return int(getattr(usage, k, 0) or 0)

    event = {
        "advance_id": advance_id,
        "model": kwargs.get("model", ""),
        "input_tokens": g("prompt_tokens"),
        "output_tokens": g("completion_tokens"),
        "cache_read_tokens": g("cache_read_input_tokens"),
        "cache_creation_tokens": g("cache_creation_input_tokens"),
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "session": kwargs.get("litellm_call_id", ""),
    }

    out = repo / ".arrive" / "usage"
    out.mkdir(parents=True, exist_ok=True)
    with (out / "litellm-events.jsonl").open("a") as f:
        f.write(json.dumps(event) + "\n")


# LiteLLM custom-logger entry points (sync + async).
def log_success_event(kwargs, response_obj, start_time, end_time):
    log_arrive_usage(kwargs, response_obj, start_time, end_time)


async def async_log_success_event(kwargs, response_obj, start_time, end_time):
    log_arrive_usage(kwargs, response_obj, start_time, end_time)
