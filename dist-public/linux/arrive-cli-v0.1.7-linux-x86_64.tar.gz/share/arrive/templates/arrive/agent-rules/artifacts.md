# ARRIVE Artifact Rules

Rules for creating and modifying ARRIVE governance artifacts. Template-first and plan workflow: `arrive-core.mdc`.

## Stable IDs

When creating or altering ARRIVE artifacts:

- **Preserve stable IDs**: `system_id`, `component_id`, `advance_id`
- IDs form the global uniqueness key: `<repo_id>/<system_id>/<component_id>`
- Never rename IDs without migration plan

## Stage Vocabulary

Use only these stages:

- `incubating` - Early stage, flexible, learning/rapid iteration
- `candidate` - Stabilized enough for normal governance
- `resident` - High trust + high scrutiny; stricter gates

## Component Definitions

Keep component definitions minimal:

- `owners` - Who is responsible
- `stage` - Current governance level
- `selectors` - How to match files (paths, modules, tags)
- `interfaces` - Public surface (optional)
- `invariants` - Only required for resident stage

## Selector Types

Components use selectors to match files:

### Path Globs (Primary)
```yaml
selectors:
  paths:
    - "core/src/auth/**"
    - "services/*/auth.rs"
```

### Tags (For Scattered Files)
When files don't fit path patterns, use in-file annotations:
```yaml
selectors:
  tags:
    - auth
    - security
```

### Build Modules (Optional)
Match by build system targets:
```yaml
selectors:
  build_modules:
    - "//services/auth:lib"
```

### Contracts (Optional)
Match by API/schema contract files:
```yaml
selectors:
  contracts:
    - "api/openapi/auth.yaml"
```

## File Annotations (@arrive)

For scattered files that don't fit path patterns, add in-file annotations.

### Annotation Format

Add near the top of the file (within first 50 lines):

**Rust:**
```rust
//! @arrive component: auth
```

**TypeScript/JavaScript:**
```typescript
// @arrive component: auth
```

**Python:**
```python
# @arrive component: auth
```

**Go:**
```go
// @arrive component: auth
```

**YAML/Config:**
```yaml
# @arrive component: auth
```

### Multiple Components

A file can belong to multiple components:
```rust
//! @arrive component: auth, logging
```

### Annotation Pattern

The scanner looks for:
```
@arrive component: <component_id>[, <component_id>...]
```

Case-insensitive, whitespace-flexible.

## Avoid Duplication

- YAML should be governance-level, not a diary
- Don't duplicate content that can be derived
- Cross-reference rather than copy
