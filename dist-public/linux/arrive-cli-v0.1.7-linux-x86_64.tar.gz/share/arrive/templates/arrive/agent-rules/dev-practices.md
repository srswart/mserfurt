# Development Practices: Tidy First + TDD

These practices are mandatory for all code changes. Reviewability thresholds: `arrive-core.mdc`; scoring and splits: `arrive-reviewability.mdc`.

## Tidy First (Kent Beck)

"Make the change easy, then make the easy change."

### What is Tidying?

Tidying is preparatory refactoring that makes behavioral changes easier:

- **Rename** - Variables, functions, types for clarity
- **Extract** - Pull out functions, modules, types
- **Inline** - Remove unnecessary indirection
- **Reorder** - Move code for better locality
- **Delete dead code** - Remove unused code paths

### Tidying Rules

1. **Tidy commits MUST NOT change behavior**
   - All existing tests must pass unchanged
   - No new functionality added
   
2. **Tidy BEFORE behavioral changes**
   - Don't mix refactoring with features
   - Makes the feature commit smaller and clearer
   
3. **Small, focused tidy commits**
   - One logical tidying per commit
   - Easy to review, easy to revert
   
4. **Commit message format**
   ```
   tidy: <what was tidied>
   
   Preparing for: <upcoming change>
   ```

### When to Tidy

- Before adding a feature to an area
- When you notice code that's hard to understand
- When test setup is complex
- When you're about to duplicate code

## Test-Driven Development (TDD)

"Write the test that describes what you want, then make it pass."

### The TDD Cycle

```
┌─────────────────────────────────────────┐
│                                         │
│   ┌─────┐    ┌───────┐    ┌──────────┐ │
│   │ RED │ -> │ GREEN │ -> │ REFACTOR │ │
│   └─────┘    └───────┘    └──────────┘ │
│      ^                          │      │
│      └──────────────────────────┘      │
│                                         │
└─────────────────────────────────────────┘
```

1. **RED**: Write a failing test
   - Test describes expected behavior
   - Test MUST fail before implementation
   - Commit: `test: <what behavior is being tested>`

2. **GREEN**: Make the test pass
   - Write minimum code to pass
   - Don't optimize yet
   - Commit: `feat: <what behavior was added>` or `fix: <what was fixed>`

3. **REFACTOR**: Clean up (if needed)
   - This is just another Tidy First cycle
   - Tests must still pass
   - Commit: `tidy: <what was cleaned>`

### TDD Requirements

| Requirement | Enforcement |
|-------------|-------------|
| Tests before implementation | Test commits must precede feature commits |
| Tests must initially fail | CI can verify test was added in failing state |
| No untested behavioral changes | Coverage gates on resident components |

### Test Commit Format

```
test: <behavior being tested>

- Adds test for <scenario>
- Expects <outcome>
- Part of: ADV-YYYY-NNNN
```

### Implementation Commit Format

```
feat: <behavior implemented>

- Makes test_<name> pass
- <brief description>
- Part of: ADV-YYYY-NNNN
```

## Combined Workflow Example

For a feature "Add user validation":

```bash
# 1. Tidy First - prepare the ground
git commit -m "tidy: extract UserInput type from handler"
git commit -m "tidy: rename validate to validate_format"

# 2. Test First - describe behavior
git commit -m "test: user validation rejects empty email"
git commit -m "test: user validation rejects invalid format"

# 3. Implement - make tests pass
git commit -m "feat: add email validation to user input"

# 4. More tidying if needed
git commit -m "tidy: extract email regex to constants"
```

## Evidence for Advances

When documenting an Advance, include:

```yaml
evidence:
  - tdd:red-green     # Tests written first, then implementation
  - tidy:preparatory  # Tidying commits preceded feature
  - tests:unit        # Unit tests passing
  - tests:integration # Integration tests passing
```

## Anti-Patterns to Avoid

❌ **Don't**: Mix tidying with features in one commit
❌ **Don't**: Write tests after implementation
❌ **Don't**: Skip tests for "simple" changes
❌ **Don't**: Large refactoring commits
❌ **Don't**: "Test later" promises

✅ **Do**: Small, focused commits
✅ **Do**: Tests describe behavior before code exists
✅ **Do**: Each commit is independently reviewable
✅ **Do**: Tidy when you see the need, before features
