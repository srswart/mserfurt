# Capturing Model/Token Usage

Each advance can record the **token usage** that produced it (`model_usage` in the advance frontmatter). This powers cost attribution, model comparison, and replay ROI. Usage is **captured by tooling, never hand-edited** — do not invent or estimate token counts.

## Do not author `model_usage` by hand

- `model_usage` is populated by `arrive usage import`. When authoring an advance, leave it empty (or omit it). The advance template ships an empty `model_usage: []` placeholder.
- Older advances with no `model_usage` are valid; the field is optional and backward-compatible. Never add `null`/`~` — omit it instead.

## When to capture

When you finish (or pause) implementing an advance, propose recording usage:

- **Claude Code**: `arrive usage import --from claude-code --advance <ID>` (reads `~/.claude/projects/...` sessions; explicit attribution).
- **LiteLLM-routed tools**: ensure the ARRIVE LiteLLM callback is installed, then `arrive usage import --from litellm` (attributes by the active advance recorded in `.arrive/work-context.json`).
- Use `--dry-run` first to preview segments; the import is idempotent (re-running updates the same `(source, session)` entry rather than duplicating).

## Reporting

- `arrive usage cost --advance <ID>` (or `--system` / `--component` / `--pass`) aggregates tokens and computes cost from `arrive/model-pricing.yaml`.
- Add `--by-generation` to separate replay passes (generation 1 vs. 2…).
- If `usage cost` warns about a model with no pricing, propose adding it to `arrive/model-pricing.yaml` rather than guessing a cost.

## Replays

On a clone/reset (replay), new work belongs to a higher `replay_generation`. Imports stamp the advance's current generation, so original and replay usage stay separated — don't merge them by hand.
