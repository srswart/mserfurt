# ARRIVE Resident Check

Verify that all required gates are satisfied when resident components are touched.

## Instructions

1. **Run the check command** in strict mode:

```bash
arrive check --strict
```

2. **If resident components are touched**, verify these gates:

   **Required Gates**:
   - [ ] **Owner Approval**: Is a component owner assigned to review?
   - [ ] **Invariant Impact Statement**: Are invariants documented and assessed?
   - [ ] **Rollback Plan**: Is there a clear way to revert this change?
   - [ ] **Evidence Links**: Are tests, CI results, or other evidence linked?

3. **Check the advance file** for required sections:

```bash
# Read the advance to verify sections exist
cat arrive/systems/*/advances/ADV-*.md
```

4. **Report missing gates** with specific guidance on how to address each.

## Gate Verification Details

### Owner Approval
- Check if PR reviewers include component owners
- Look at `arrive/systems/*/components/*.yaml` for owner definitions
- Suggest adding appropriate reviewers

### Invariant Impact Statement
- Look for "Invariant Impact" or similar section in advance
- Should describe:
  - Which invariants could be affected
  - Why they remain intact OR
  - How violations are mitigated

### Rollback Plan
- Look for "Rollback" section in advance
- Should describe:
  - Steps to revert the change
  - Any data migration considerations
  - Dependencies that need coordination

### Evidence Links
- Look for "Evidence" section in advance
- Should include:
  - Test results (unit, integration)
  - CI/CD pipeline links
  - Manual verification notes

## Expected Output Format

### When All Gates Pass:

```
✅ Resident Gates Passed

Resident Components Touched:
└─ component-name in system-name

Gate Status:
✓ Owner Approval - [owner] assigned
✓ Invariant Impact - Statement present
✓ Rollback Plan - Documented
✓ Evidence Links - N items linked

All gates satisfied. Proceed with merge.
```

### When Gates Are Missing:

```
⚠️ Resident Gates Incomplete

Resident Components Touched:
└─ component-name in system-name

Gate Status:
✓ Owner Approval - [owner] assigned
✗ Invariant Impact - MISSING
✗ Rollback Plan - MISSING
✓ Evidence Links - 2 items linked

Required Actions:

1. Add Invariant Impact Statement:
   Document in the advance which invariants are affected
   and how they remain intact.

2. Add Rollback Plan:
   Document in the advance how to revert this change
   if issues are discovered.

Run /arrive-resident-check again after addressing these items.
```
