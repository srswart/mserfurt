# ARRIVE Log

Record a change entry in the current Advance's "Changes Made" section.

## Instructions

1. **Identify the current advance**:
   - Look for the advance associated with current work
   - Check recent conversation for advance ID mentions
   - Or detect from `arrive status` output

2. **Get the change details from the user**:
   - **Commit type**: tidy, test, feat, fix, docs, chore
   - **Summary**: Brief description of what was done

3. **Run the log command**:

```bash
arrive log --advance ADV-XXX-NNN --commit-type [type] --summary "[summary]"
```

4. **Confirm the entry was added** by reading the advance file.

## Commit Types

| Type | When to Use |
|------|-------------|
| `tidy` | Preparatory refactoring (no behavior change) |
| `test` | Adding or modifying tests |
| `feat` | New feature implementation |
| `fix` | Bug fix |
| `docs` | Documentation changes |
| `chore` | Build, CI, tooling changes |

## User Interaction

Ask the user for:
1. The advance ID (if not obvious from context)
2. The commit type (suggest based on recent work)
3. A brief summary of what was done

Example prompts:
- "What type of change is this? (tidy/test/feat/fix)"
- "Brief summary of what you just completed?"

## Expected Output Format

```
📋 Change Logged

Advance: ADV-[COMPONENT]-NNN
Entry Added:

### [date]: [type] - [summary]
- file1.rs: Description
- file2.rs: Description

✓ Changes Made section updated
```

## Follow-up Suggestions

After logging a change:
- If commit type was `test`, remind about running tests
- If score is increasing, suggest `/arrive-checkpoint`
- If ready to commit, suggest appropriate commit message format
