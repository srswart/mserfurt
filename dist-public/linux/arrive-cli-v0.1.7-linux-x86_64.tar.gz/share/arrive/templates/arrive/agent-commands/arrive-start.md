# ARRIVE Start

Initialize a new change session by detecting the current context and setting up an advance.

## Instructions

1. **Get the current branch name** to understand context:

```bash
git branch --show-current
```

2. **Check for existing changes** in the working directory:

```bash
arrive status
```

3. **Look for existing planned advances** in the detected system(s):
   - Check `arrive/systems/*/advances/` for advances with `status: planned`
   - If a planned advance exists for the primary component, suggest using it

4. **If no planned advance exists**, offer to create one:
   - Run `arrive draft` to generate a new advance
   - Suggest a title based on the branch name or user's stated goal

5. **Summarize the session start**:
   - Current branch
   - Systems/components detected
   - Associated advance (existing or newly created)
   - Confirm time tracking fields are set (`started_at` always; `implementation_completed_at` when done)
   - Next steps (implement, test, commit)

## User Interaction

If the user provides a goal description, use it to:
- Inform the advance title
- Set context for the objective section

If no goal is provided, infer from:
- Branch name (e.g., `feature/add-auth` → "Add authentication")
- Changed files pattern

## Expected Output Format

```
🚀 ARRIVE Session Started

Branch: feature/your-branch-name
Goal: [user's stated goal or inferred from branch]

Detected Impact:
├─ system-name
│  └─ component-name (stage)
└─ Files: N changed

Advance: ADV-COMPONENT-NNN
├─ Status: Planned
├─ Path: arrive/systems/.../advances/ADV-COMPONENT-NNN.md
└─ Score: XX [LEVEL]

Next Steps:
1. Implement changes (tidy first, then tests, then features)
2. Run /arrive-status to monitor reviewability
3. Run /arrive-log to record progress
4. Run /arrive-checkpoint if score goes Yellow/Red
```
