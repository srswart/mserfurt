# ARRIVE CFU (Check for Understanding)

Generate questions that help reviewers deeply understand the change, not just approve it.
Prefer advance-driven grounding over generic repo-wide prompts.

## Instructions

1. **Analyze the current change context**:

```bash
arrive status --verbose
arrive score
```

2. **Read the advance file first** as the primary source of CFU topics:
   - Objective and behavioral change
   - Implementation approach
   - Risk factors
   - Design decisions
   - Changed files listed in `Changes Made` (primary scope for code analysis)

3. **Generate 3-5 CFU questions** that probe understanding of:

   **Why Questions** (Architectural Decisions):
   - Why was this approach chosen over alternatives?
   - Why is this the right place for this code?
   - Why is this abstraction level appropriate?

   **What-If Questions** (Risk Tradeoffs):
   - What happens if [edge case]?
   - What would break if this invariant is violated?
   - What's the fallback if this fails?

   **How Questions** (Behavioral Changes):
   - How does this change user experience?
   - How does this affect performance/security?
   - How would you verify this works correctly?

4. **Tailor questions** to the specific change and scoped files:
   - For auth changes: Focus on security implications
   - For data changes: Focus on migration and integrity
   - For API changes: Focus on compatibility and contracts
   - For performance changes: Focus on benchmarks and tradeoffs

## Question Quality Guidelines

**Good CFU Questions**:
- Cannot be answered with just "yes" or "no"
- Require understanding the code, not just reading it
- Reveal assumptions that should be verified
- Help the reviewer spot issues they might miss

**Avoid**:
- Questions that are answered in the PR description
- Implementation detail questions ("why use forEach vs map?")
- Questions with obvious answers
- Too many questions (stick to 3-5 most important)

## Expected Output Format

```
🎓 Check for Understanding Questions

For: ADV-[COMPONENT]-NNN - [Title]

These questions help verify reviewer understanding:

1. **[Category]**: [Question]
   > Hint: [Brief context to help frame the answer]

2. **[Category]**: [Question]
   > Hint: [Brief context]

3. **[Category]**: [Question]
   > Hint: [Brief context]

4. **[Category]**: [Question]
   > Hint: [Brief context]

5. **[Category]**: [Question]
   > Hint: [Brief context]

💡 Add these to your PR description or discuss in review comments.
```

## Regeneration Guidance

If the question set quality is weak, regenerate from ARRIVE CLI for the same advance:

```bash
arrive advance cfu <ADV-ID> --refresh
```

Need a different deterministic variant:

```bash
arrive advance cfu <ADV-ID> --refresh --reroll
# or reproducible variant
arrive advance cfu <ADV-ID> --refresh --seed 42
```

## Example Questions by Domain

**Authentication/Security**:
- What attack vectors does this change expose or mitigate?
- How does this change affect the principle of least privilege?

**Data/Persistence**:
- What happens to existing data when this deploys?
- How do we handle the case where migration fails midway?

**API/Contracts**:
- Which clients will be affected by this change?
- What's the backwards compatibility story?

**Performance**:
- Under what conditions could this become a bottleneck?
- What's the expected latency/throughput impact?

**Concurrency**:
- What ordering guarantees does this code assume?
- What happens if two requests hit this simultaneously?
